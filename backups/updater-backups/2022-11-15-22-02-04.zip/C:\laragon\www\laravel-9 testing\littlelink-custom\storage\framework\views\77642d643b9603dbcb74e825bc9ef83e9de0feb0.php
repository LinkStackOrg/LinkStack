<?php
$analyticsHTML = config('advanced-config.analytics');
$analyticsHTML = preg_replace("~<!--(.*?)-->~s", "", $analyticsHTML);
$analyticsHTML = trim($analyticsHTML);
?>

<?php if(preg_replace( "/\r|\n/", "", $analyticsHTML ) != ''): ?>
<!-- Analytics -->

<?php echo $analyticsHTML; ?>


<!-- /Analytics -->
<?php endif; ?>
<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/layouts/analytics.blade.php ENDPATH**/ ?>