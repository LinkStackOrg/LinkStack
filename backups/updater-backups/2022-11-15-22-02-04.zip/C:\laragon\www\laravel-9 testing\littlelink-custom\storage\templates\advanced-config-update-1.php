

    /*
    |--------------------------------------------------------------------------
    | Extra Settings
    |--------------------------------------------------------------------------
    |
    */

    // Expands admin menu on the Admin Panel Sidebar permanently
    'expand_panel_admin_menu_permanently' => 'false', // Either "true" or "false".

    // Should only be used in a local testing environment
    'disable_default_password_notice' => 'false', // Either "true" or "false".

];