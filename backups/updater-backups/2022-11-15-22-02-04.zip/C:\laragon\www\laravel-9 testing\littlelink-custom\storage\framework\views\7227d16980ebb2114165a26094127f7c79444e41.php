

<?php $__env->startSection('content'); ?>

<style>
.nav-tabs {
    border-bottom: 1px solid #ddd;
}

.nav-tabs > li.active > a,
.nav-tabs > li.active > a:hover,
.nav-tabs > li.active > a:focus {
    color: #555;
    cursor: default;
    background-color: #fff;
    border: 1px solid #ddd;
    border-bottom-color: transparent;
}

.nav-tabs > li > a {
    margin-right: 2px;
    line-height: 1.428571429;
    border: 1px solid transparent;
    border-radius: 4px 4px 0 0;
}

.nav-tabs > li > a:hover {
    border-color: #eee #eee #ddd;
}

.nav-tabs > li > a:focus {
    outline: none;
}

.tab-content > .tab-pane {
    display: none;
}

.tab-content > .active {
    display: block;
}

ul {
  padding: 0;
}

ul.nav {
  list-style: none;
  margin: 0;
  padding: 0;
}

ul.nav > li {
  float: left;
}

ul.nav > li > a {
  display: block;
  padding: 3px 10px;
  text-decoration: none;
}

ul.nav > li.active > a,
ul.nav > li > a:hover {
  background-color: #eee;
}

.tab-content {
  border-top: none;
  padding: 10px;
}

.tab-content > .tab-pane {
  padding: 5px;
}
</style>

<div class=""><h2>Tabs</h2></div>

<div id="exTab2" class="">	
<ul class="nav nav-tabs">
			<li class="active">
            <a  href="#1" data-toggle="tab">Config</a>
			</li>
			<li><a href="#2" data-toggle="tab">Advanced Config Editor</a>
			</li>
			<li><a href="#3" data-toggle="tab">Alterntive Config Editor</a>
			</li>
			<li><a href="#4" data-toggle="tab">Backups</a>
			</li>
			<li><a href="#5" data-toggle="tab">Backups</a>
			</li>
		</ul>
<div class="tab-content ">


<div class="tab-pane active" id="1">
<section class="shadow text-gray-400">
<h2 class="mb-4 card-header"><i class="bi bi-link-45deg"> Config</i></h2>
<div class="card-body p-0 p-md-3">

test1

</div>
</section>

</div>
<div class="tab-pane" id="2">
<section class="shadow text-gray-400">
<h2 class="mb-4 card-header"><i class="bi bi-link-45deg"> Advanced Config Editor</i></h2>
<div class="card-body p-0 p-md-3">

        <h2 class="mb-4"><i class="bi bi-pencil-square"> Advanced config</i></h2>
          <p>Allows editing the frontend of your site. Amongst other things, this file allows customization of:<br> 
Home Page, links, titles, Google Analytics and meta tags.</p>
        <form action="<?php echo e(route('editAC')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Advanced Configuration file.</label>
            <pre><textarea style="width:100%;" class="form-control" name="AdvancedConfig" rows="280"><?php echo e(file_get_contents('config/advanced-config.php')); ?></textarea></pre>
          </div>
          <button type="submit" class="mt-3 ml-3 btn btn-info">Save</button>
          <a class="mt-3 ml-3 btn btn-primary confirmation" href="<?php echo e(url('/panel/advanced-config?restore-defaults')); ?>">Restore defaults</a>
          <script type="text/javascript">
              var elems = document.getElementsByClassName('confirmation');
              var confirmIt = function (e) {
                  if (!confirm('Are you sure?')) e.preventDefault();
              };
              for (var i = 0, l = elems.length; i < l; i++) {
                  elems[i].addEventListener('click', confirmIt, false);
              }
          </script>
        </form>

</div>
</section>
</div>


<div class="tab-pane" id="3">
<section class="shadow text-gray-400">
<h2 class="mb-4 card-header"><i class="bi bi-link-45deg"> Alterntive Config Editor</i></h2>
<div class="card-body p-0 p-md-3">
<h2 class="mb-4"><i class="bi bi-pencil-square"> ENV</i></h2>

        <form action="<?php echo e(route('editENV')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>.env</label>
            <pre><textarea style="width:100%!important;" class="form-control" name="AdvancedConfig" rows="<?php echo e(count(file('.env'))); ?>"><?php echo e(file_get_contents('.env')); ?></textarea></pre>
          </div>
          <button type="submit" class="mt-3 ml-3 btn btn-info">Save</button>
        </form>

</div>
</section>
</div>


<div class="tab-pane active" id="4">
<section class="shadow text-gray-400">
<h2 class="mb-4 card-header"><i class="bi bi-link-45deg"> Backup</i></h2>
<div class="card-body p-0 p-md-3">

<div class="container">


<?php if($_SERVER['QUERY_STRING'] === ''): ?>
<?php //landing page ?>
        
        <div class="logo-container fadein">
           <img class="logo-img" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="Logo">
           <div class="logo-centered">l</div>
        </div>
        <h1>Backup</h1>
        <h4 class="">You can back up your entire instance:</h4>
        <h5 class="">The backup system won't save more than two backups at a time.</h5>
        <br><div class="row">
        &ensp;<a class="btn" href="<?php echo e(url()->current()); ?>/?backup"><button><i class="fa-solid fa-floppy-disk"></i> Backup Instance</button></a>&ensp;
        &ensp;<a class="btn" href="<?php echo e(route('showBackups')); ?>"><button><i class="fa-solid fa-box-archive"></i> All Backups</button></a>&ensp;
        </div>
        <?php endif; ?>


<?php if($_SERVER['QUERY_STRING'] === 'backup'): ?>
<?php //creating backup... ?>
<?php $__env->startPush('updater-head'); ?>
<meta http-equiv="refresh" content="2; URL=<?php echo e(url()->current()); ?>/?backups" />
<?php $__env->stopPush(); ?>
        <div class="logo-container fadein">
           <img class="logo-img loading" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="Logo">
           <div class="logo-centered">l</div>
        </div>
        <h1 class="loadingtxt">Creating backup</h1>
<?php endif; ?>

<?php if($_SERVER['QUERY_STRING'] === 'backups'): ?>
<?php Artisan::call('backup:clean');
Artisan::call('backup:run', ['--only-files' => true]);
$tst = base_path('backups/');
file_put_contents($tst.'CANUPDATE', '');
$URL = Route::current()->getName();   
header("Location: ".$URL."?success");
exit(); ?>
<?php endif; ?>

<?php if($_SERVER['QUERY_STRING'] === 'success'): ?>
      <?php //after successfully updating ?>
        
        <div class="logo-container fadein">
           <img class="logo-img" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="Logo">
           <div class="logo-centered">l</div>
        </div>
        <h1>Success!</h1>
        <h4 class="">The backup was successful, you can now return to the Admin Panel or see all your backups.</h4>
        <br><div class="row">
        &ensp;<a class="btn" href="<?php echo e(route('studioIndex')); ?>"><button><i class="fa-solid fa-house-laptop btn"></i> Admin Panel</button></a>&ensp;
        &ensp;<a class="btn" href="<?php echo e(route('showBackups')); ?>"><button><i class="fa-solid fa-box-archive"></i> All Backups</button></a>&ensp;
        </div>
<?php endif; ?>

</div>

</div>
</section>
</div>


<div class="tab-pane active" id="5">
<section class="shadow text-gray-400">
<h2 class="mb-4 card-header"><i class="bi bi-link-45deg"> Config</i></h2>
<div class="card-body p-0 p-md-3">

test1

</div>
</section>
</div>


</div>
</div>



<?php $__env->startPush("sidebar-scripts"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.updater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views//panel/config-editor.blade.php ENDPATH**/ ?>