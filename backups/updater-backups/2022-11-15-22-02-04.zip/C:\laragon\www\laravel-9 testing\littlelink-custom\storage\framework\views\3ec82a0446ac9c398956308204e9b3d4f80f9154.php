<div class="container">
<div class="footer fadein" style="margin:5% 0px 35px 0px;">
<?php if(env('DISPLAY_FOOTER') === true): ?>
    <?php if(config('advanced-config.display_link_home') != 'false'): ?><a class="footer-hover spacing" <?php if(config('advanced-config.custom_link_home') != ''): ?>href="<?php echo e(config('advanced-config.custom_link_home')); ?>"<?php else: ?> href="<?php echo e(url('')); ?>/"<?php endif; ?>> <?php if(config('advanced-config.custom_text_home') != ''): ?><?php echo e(config('advanced-config.custom_text_home')); ?><?php else: ?> Home <?php endif; ?></a><?php endif; ?>
    <?php if(config('advanced-config.display_link_terms') != 'false'): ?><a class="footer-hover spacing" href="<?php echo e(url('')); ?>/pages/terms">Terms</a><?php endif; ?>
    <?php if(config('advanced-config.display_link_privacy') != 'false'): ?><a class="footer-hover spacing" href="<?php echo e(url('')); ?>/pages/privacy">Privacy</a><?php endif; ?>
    <?php if(config('advanced-config.display_link_contact') != 'false'): ?><a class="footer-hover spacing" href="<?php echo e(url('')); ?>/pages/contact">Contact</a><?php endif; ?>
<?php endif; ?>
</div>

<?php if(env('DISPLAY_CREDIT') === true): ?>
<div class="credit-footer"><a style="text-decoration: none;" class="spacing" href="https://littlelink-custom.com" target="_blank" title="Learn more">
	<section class="credit-hover hvr-grow fadein">
		<div class="parent-footer credit-icon" >
			<img id="footer_spin" class="footer_spin image-footer1 generic" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="LittleLink Custom"></img>
			<img class="image-footer2" src="<?php echo e(asset('littlelink/images/just-ll.svg')); ?>" alt="LittleLink Custom"></img>
		</div>

		<a href="https://littlelink-custom.com" target="_blank" title="Learn more" class="credit-txt credit-txt-clr credit-text">Powered by LittleLink Custom</a>
	</section>
</a></div><br><br><br>
<?php endif; ?>
</div><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/layouts/footer.blade.php ENDPATH**/ ?>