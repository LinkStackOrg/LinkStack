


<?php $__env->startSection('content'); ?>
<?php if($littlelink_name == ''): ?>
        <h3 class="mb-4"> 👋 Hi, stranger</h3>
        <h5>You do not have a Page URL set, yet you can change that on the <a href="<?php echo e(url('/studio/page')); ?>">Page section</a></h5>
	<?php else: ?>
        <h3 class="mb-4"> 👋 Hi, @<?= $littlelink_name ?></h2>
		<?php endif; ?>
        <p>
          Welcome to <?php echo e(config('app.name')); ?>!
        </p>


        <!-- Section: Design Block -->
        <section class="mb-3 text-gray-800 text-center shadow p-4 w-full">
            <div class='font-weight-bold text-left'>User stats:</div>
            <div class="d-flex flex-wrap justify-content-around">

                <div class="p-2">
                    <h3 class="text-primary"><strong><i class="bi bi-share-fill"> <?php echo e($siteLinks); ?> </i></strong></h3>
                    <span class="text-muted">Total links</span>
                </div>

                <div class="p-2">
                    <h3 class="text-primary"><strong><i class="bi bi-eye-fill"> <?php echo e($siteClicks); ?> </i></strong></h3>
                    <span class="text-muted">Total clicks</span>
                </div>

                <div class="p-2">
                    <h3 class="text-primary"><strong><i class="bi bi bi-person-fill"> <?php echo e($userNumber); ?></i></strong></h3>
                    <span class="text-muted">Total users</span>
                </div>

            </div>
        </section>

        <section class="mb-3 text-center shadow p-4 w-full">
            <div class=" d-flex">

                <div class='p-2 h6'><i class="bi bi-link"> Links: <?php echo e($links); ?> </i></span></div>

                <div class='p-2 h6'><i class="bi bi-eye"> Clicks: <?php echo e($clicks); ?> </i></span></div>
            </div>
        </section>



        

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/panel/index.blade.php ENDPATH**/ ?>