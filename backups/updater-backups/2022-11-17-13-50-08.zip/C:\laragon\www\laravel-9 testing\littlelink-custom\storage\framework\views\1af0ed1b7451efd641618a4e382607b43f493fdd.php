<label for='button' class='form-label'>Select a predefined site</label>
<?php use App\Models\Button; $button = Button::find($button_id); if(isset($button->name)){$buttonName = $button->name;}else{$buttonName = 0;} ?>

<select name='button' class='form-control'>
        <?php if($buttonName != 0): ?><option value='<?php echo e($buttonName); ?>'><?php echo e(ucfirst($buttonName)); ?></option><?php endif; ?>
    <?php $__currentLoopData = $buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!in_array($b["name"], ["custom_website", "custom", $buttonName])): ?>
        <option class='button button-<?php echo e($b["name"]); ?>' value='<?php echo e($b["name"]); ?>' <?php echo e($b["selected"] == true ? "selected" : ""); ?>><?php echo e($b["title"]); ?></option>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<label for='title' class='form-label'>Custom Title</label>
<input type='text' name='title' value='<?php echo e($link_title); ?>' class='form-control' />
<span class='small text-muted'>Leave blank for default title</span><br>

<label for='link' class='form-label'>URL</label>
<input type='url' name='link' value='<?php echo e($link_url); ?>' class='form-control' required />
<span class='small text-muted'>Enter the link URL</span>

<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/components/pageitems/predefined-form.blade.php ENDPATH**/ ?>