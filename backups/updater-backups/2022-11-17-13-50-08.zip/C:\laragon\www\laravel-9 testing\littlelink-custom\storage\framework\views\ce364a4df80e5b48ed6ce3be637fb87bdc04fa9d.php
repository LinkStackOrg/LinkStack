<!DOCTYPE html>
<?php echo $__env->make('layouts.lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
  <meta charset="utf-8">

<?php $GLOBALS['themeName'] = config('advanced-config.home_theme'); ?>

<?php
// Theme Config
function theme($key){
$key = trim($key);
$file = base_path('themes/' . $GLOBALS['themeName'] . '/config.php');
  if (file_exists($file)) {
    $config = include $file;
  if (isset($config[$key])) {
    return $config[$key];
}}
return null;}

// Theme Custom Asset
function themeAsset($path){
$path = url('themes/' . $GLOBALS['themeName'] . '/extra/custom-assets/' . $path);
return $path;}
?>

<?php if(theme('enable_custom_code') == "true" and theme('enable_custom_head') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

<?php echo $__env->make('layouts.analytics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php if(env('CUSTOM_META_TAGS') == 'true' and config('advanced-config.title') != ''): ?>
  <title><?php echo e(config('advanced-config.title')); ?></title>
  <?php else: ?>
  <title><?php echo e(config('app.name')); ?></title>
  <?php endif; ?>

  <?php $cleaner_input = strip_tags($message->home_message); ?>

  <?php if(env('CUSTOM_META_TAGS') == 'true'): ?>
  <?php echo $__env->make('layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  <?php else: ?>
  <meta name="description" content="<?php echo e($cleaner_input); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php endif; ?>

  <!-- Custom icons font-awesome -->
  <script src="https://kit.fontawesome.com/c4a5e06183.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css" integrity="sha384-fZCoUih8XsaUZnNDOiLqnby1tMJ0sE7oBbNk2Xxf5x8Z4SvNQ9j83vFMa/erbVrV" crossorigin="anonymous"/>

  <link href="//fonts.bunny.net/css?family=Open+Sans:400,600,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/normalize.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/animate.css')); ?>">
  <?php if(file_exists(base_path("littlelink/images/avatar.png" ))): ?>
  <link rel="icon" type="image/png" href="<?php echo e(asset('littlelink/images/avatar.png')); ?>">
  <?php else: ?>
  <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('littlelink/images/logo.svg')); ?>">
  <?php endif; ?>

<?php if(config('advanced-config.home_theme') != '' and config('advanced-config.home_theme') != 'default'): ?>

  <!-- LittleLink Custom Theme: "<?php echo e(config('advanced-config.home_theme')); ?>" -->

  <link rel="stylesheet" href="themes/<?php echo e(config('advanced-config.home_theme')); ?>/brands.css">
  <link rel="stylesheet" href="themes/<?php echo e(config('advanced-config.home_theme')); ?>/skeleton-auto.css">
<?php if(file_exists(base_path('themes/' . config('advanced-config.home_theme') . '/animations.css'))): ?>
  <link rel="stylesheet" href="<?php echo asset('themes/' . config('advanced-config.home_theme') . '/animations.css') ?>">
<?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/animations.css')); ?>">
<?php endif; ?>

<?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/brands.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/animations.css')); ?>">
  <?php // override dark/light mode if override cookie is set
  $color_scheme_override = isset($_COOKIE["color_scheme_override"]) ? $_COOKIE["color_scheme_override"] : false; ?>
  <?php if($color_scheme_override == 'dark'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/skeleton-dark.css')); ?>">
  <?php elseif($color_scheme_override == 'light'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/skeleton-light.css')); ?>">
  <?php elseif(config('advanced-config.theme') == 'dark'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/skeleton-dark.css')); ?>">
  <?php elseif(config('advanced-config.theme') == 'light'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/skeleton-light.css')); ?>">
  <?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('littlelink/css/skeleton-auto.css')); ?>">
  <?php endif; ?>
<?php endif; ?>

                                                        
  <style>@font-face{font-family:'ll';src:url(<?php echo e(asset('littlelink/fonts/littlelink-custom.otf')); ?>) format("opentype")}</style>

<style>

.reg {
    background-color: #0085FF;
    border: 1px solid transparent;
}
.reg a {
 color: #fff;
}

.log {
  background-color: #fefefe;
  border: 1px solid #000;
}
.log a {
 color: #333;
}

.btns {
    display: inline-block;
    font-weight: 400;
    text-align: center;
    vertical-align: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    margin-left: 0.75rem;
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
    border-radius: 0.25rem;
    -webkit-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
    -o-transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
}
</style>

</head>
<body>

<?php if(theme('enable_custom_code') == "true" and theme('enable_custom_body') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

<?php if(config('advanced-config.home_theme') != '' and config('advanced-config.home_theme') != 'default'): ?>
    <!-- Enables parallax background animations -->
    <div class="background-container">
    <section class="parallax-background">
      <div id="object1" class="object1"></div>
      <div id="object2" class="object2"></div>
      <div id="object3" class="object3"></div>
      <div id="object4" class="object4"></div>
      <div id="object5" class="object5"></div>
      <div id="object6" class="object6"></div>
      <div id="object7" class="object7"></div>
      <div id="object8" class="object8"></div>
      <div id="object9" class="object9"></div>
      <div id="object10" class="object10"></div>
      <div id="object11" class="object11"></div>
      <div id="object12" class="object12"></div>
    </section>
    </div>
    <!-- End of parallax background animations -->
<?php endif; ?>

<?php
$pages = DB::table('pages')->get();
foreach($pages as $page)
{
	//Gets value from database
}
?>

  <div class="container">
    <div class="row">
    <div class="sign" style="margin-top: 30px; text-align: right;">
            <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="fadein btns log"><a href="<?php echo e(route('studioIndex')); ?>" class="underline spacing">Studio</a></div>
                    <?php else: ?>
                        <div class="fadein btns log"><a href="<?php echo e(route('login')); ?>" class="underline spacing">Log in</a></div>

                        <?php if(Route::has('register') and $page->register == 'true'): ?>
                            <div class="fadein btns reg"><a href="<?php echo e(route('register')); ?>" class="underline spacing">Register</a></div>
                        <?php elseif(env('REGISTER_OVERRIDE') === true): ?>
                            <div class="fadein btns reg"><a href="<?php echo e(route('register')); ?>" class="underline spacing">Register</a></div>
                        <?php endif; ?>
                    <?php endif; ?>
              <?php endif; ?>
    </div>
      <div class="column" style="margin-top: 15%">
        <!-- Your Image Here -->
        <?php if(file_exists(base_path("littlelink/images/avatar.png" ))): ?>
        <img alt="avatar" src="<?php echo e(asset('littlelink/images/avatar.png')); ?>" srcset="<?php echo e(asset('littlelink/images/avatar@2x.png 2x')); ?>" width="128px" height="128px">
        <?php else: ?>
        <div class="logo-container fadein">
           <img class="rotate" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="Logo" style="width:150px; height:150px;">
           <div class="logo-centered">l</div>
        </div>
        <?php endif; ?>

        <!-- Your Name -->
        <h1 class="mt-5 fadein"> <?php echo e(config('app.name')); ?> </h1>

        <!-- Short Bio -->
        <div class="mt-5 fadein">
		      <?php echo $message->home_message; ?>
        </div>
        

        <!-- Buttons -->
<?php function strp($urlStrp){return str_replace(array('http://', 'https://'), '', $urlStrp);} ?>
<?php $initial=1; // <-- Effectively sets the initial loading time of the buttons. This value should be left at 1. ?>
<?php if(config('advanced-config.use_custom_buttons') == 'true'): ?>
        <?php $array = config('advanced-config.buttons'); ?>
        <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php $linkName = str_replace('default ','',$button['button']) ?>
         <?php if($button['button'] === "custom" and ($button['custom_css'] === "" or $button['custom_css'] === "NULL") or (theme('allow_custom_buttons') == "false" and $button['button'] === "custom")): ?>
         <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-<?php echo e($button['button']); ?> button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><?php if($button['icon'] == 'llc'): ?><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('\/littlelink/icons\/')); ?>llc.svg"><?php else: ?><i style="color: <?php echo e($button['icon']); ?>" class="icon hvr-icon fa <?php echo e($button['icon']); ?>"></i><?php endif; ?> <?php echo e($button['title']); ?></a></div>
         <?php elseif($button['button'] === "custom" and $button['custom_css'] != ""): ?>
         <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-hover icon-hover" style="<?php echo e($button['custom_css']); ?>" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><?php if($button['icon'] == 'llc'): ?><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('\/littlelink/icons\/')); ?>llc.svg"><?php else: ?><i style="color: <?php echo e($button['icon']); ?>" class="icon hvr-icon fa <?php echo e($button['icon']); ?>"></i><?php endif; ?><?php echo e($button['title']); ?></a></div>
         <?php elseif($button['button'] === "buy me a coffee"): ?>
         <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-coffee button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="button-icon" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/coffee<?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/littlelink/icons\/')); ?>coffee.svg <?php endif; ?>">Buy me a Coffee</a></div>
         <?php elseif($button['button'] === "custom_website" and ($button['custom_css'] === "" or $button['custom_css'] === "NULL") or (theme('allow_custom_buttons') == "false" and $button['button'] === "custom_website")): ?>
         <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-custom_website button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="button-icon" class="icon hvr-icon" src="https://icons.duckduckgo.com/ip3/<?php echo e(strp($button['link'])); ?>.ico"><?php echo e($button['title']); ?></a></div>
         <?php elseif($button['button'] === "custom_website" and $button['custom_css'] != ""): ?>
         <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-hover icon-hover" style="<?php echo e($button['custom_css']); ?>" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="button-icon" class="icon hvr-icon" src="https://icons.duckduckgo.com/ip3/<?php echo e(strp($button['link'])); ?>.ico"><?php echo e($button['title']); ?></a></div>
         <?php elseif($button['button'] === "space"): ?>
         <?php 
          if (is_numeric($button['title']) and $button['title'] < 10)
          echo str_repeat("<br>",$button['title']);
          elseif (is_numeric($button['title']) and $button['title'] >= 10)
          echo str_repeat("<br>",10);
          else
          echo "<br><br><br>"
          ?>
         <?php elseif($button['button'] === "heading"): ?>
         <h2><?php echo e($button['title']); ?></h2>
         <?php else: ?>
         <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-<?php echo e($button['button']); ?> button button-hover icon-hover" <?php if($button['link'] != ''): ?> href="<?php echo e($button['link']); ?>" target="_blank"<?php endif; ?>><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('\/littlelink/icons\/') . $linkName); ?>.svg"><?php echo e(ucfirst($linkName)); ?></a></div>
         <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><div class="button button-github button button-hover icon-hover"><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('littlelink/icons/github.svg')); ?>">Github</div></div>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><div class="button button-twitter button button-hover icon-hover"><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('littlelink/icons/twitter.svg')); ?>">Twitter</div></div>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><div class="button button-instagram button button-hover icon-hover"><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('littlelink/icons/instagram.svg')); ?>">Instagram</div></div>
<?php endif; ?>
        </br></br>

      <div class="fadein">
        <?php if(config('advanced-config.home_footer') == 'custom'): ?>
        <p><?php $year = date("Y"); echo strtr(config('advanced-config.custom_home_footer_text'), array('{year}' => $year)); ?></p>
        <?php elseif(config('advanced-config.home_footer') == 'alt'): ?>
        <p><i style="position:relative;top:1px;" class="fa-solid fa-infinity"></i> - Button combinations</p>
        <?php elseif(config('advanced-config.home_footer') == 'false'): ?>
        <?php else: ?>
        <p>and <?php echo e($countButton - 3); ?> other buttons ...</p>
        <?php endif; ?>
      </div>

        <hr class="my-4" style="display:none">

        <p style="display:none">updated pages</p>

        <div class="updated" style="display:none">
        <?php $__currentLoopData = $updatedPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(file_exists(base_path("img/$page->littlelink_name" . ".png" ))): ?>
          <a href="<?php echo e(url('')); ?>/@<?= $page->littlelink_name ?>" target="_blank">
          <img src="<?php echo e(asset("img/$page->littlelink_name" . ".png")); ?>" srcset="<?php echo e(asset("img/$page->littlelink_name" . "@2x.png 2x")); ?>" width="50px" height="50px">
          </a>
          <?php else: ?>
          <a href="<?php echo e(url('')); ?>/@<?= $page->littlelink_name ?>" target="_blank">
          <img src="<?php echo e(asset('littlelink/images/logo.svg')); ?>" srcset="<?php echo e(asset('littlelink/images/avatar@2x.png 2x')); ?>" width="50px" height="50px">
          </a>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </div>
    </div>
  </div>
</body>

<?php if(theme('enable_custom_code') == "true" and theme('enable_custom_body_end') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-body-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

</html>
<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/home.blade.php ENDPATH**/ ?>