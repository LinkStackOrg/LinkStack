

<?php $__env->startSection('content'); ?>

<?php if($_SERVER['QUERY_STRING'] === ''): ?>
<section class="shadow text-gray-400">
        <h3 class="mb-4 card-header"><i class="bi bi-person"> Account Settings</i></h3>
<div class="card-body p-0 p-md-3">

        <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        

<?php if(env('REGISTER_AUTH') != 'verified' or auth()->user()->role == 'admin'): ?>
        <form  action="<?php echo e(route('editProfile')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="form-group col-lg-8">
            <h4>Email</h4>
            <input type="email" class="form-control" name="email" value="<?php echo e($profile->email); ?>" required>
          </div>
          <button type="Change " class="mt-3 ml-3 btn btn-info">Change email</button>
        </form>
<?php endif; ?>

        <br><br><form  action="<?php echo e(route('editProfile')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="form-group col-lg-8">
            <h4>Password</h4>
            <input type="password" name="password" class="form-control" placeholder="At least 8 characters" required>
          </div>
          <button type="Change " class="mt-3 ml-3 btn btn-info">Change password</button>
        </form>
		
        <?php echo csrf_field(); ?>
          <br><br><div class="form-group col-lg-8">
            <h4>Role</h4>
            <input type="text" class="form-control" value="<?php echo e(strtoupper($profile->role)); ?>" readonly>
          </div>
          <br><button class="mt-3 ml-3 btn btn-primary" style="margin-bottom:2rem;margin-top:2rem!important;background-color:tomato!important;border-color:tomato!important;"><a href="<?php echo e(url('/studio/profile/?delete')); ?>" style="color:#FFFFFF;"><i class="bi bi-exclamation-octagon-fill"></i> Delete your account</a></button>
          </div>
</section>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if($_SERVER['QUERY_STRING'] === 'delete'): ?>
<center style="margin-top: 14%;">
    <h2 style="text-decoration: underline;">You are about to delete your account!</h2>
    <p>You are about to delete your account! This action cannot be undone.</p>
    <div>
        <button class="redButton mt-3 ml-3 btn btn-primary" style="width:10rem; background-color:tomato!important;border-color:tomato!important; filter: grayscale(100%);" disabled onclick="window.location.href = '<?php echo e(url('/studio/delete-user/') . "/" . Auth::id()); ?>';"><i class="bi bi-exclamation-diamond-fill"></i></button>
        <button type="submit" class="mt-3 ml-3 btn btn-info"><a style="color:#fff;" href="<?php echo e(url('/studio/profile')); ?>">Cancel</a></button>
    </div>

<script>
var seconds = 10;
var interval = setInterval(function() {
    document.querySelector(".redButton").innerHTML = --seconds;

    if (seconds <= 0)
        clearInterval(interval);

}, 1000);

setTimeout(function(){
  document.querySelector(".redButton").disabled = false;
  document.querySelector(".redButton").innerHTML = 'Delete account';
  document.querySelector(".redButton").style.filter = "none";
}, 10000);
</script>
</center>


<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views//studio/profile.blade.php ENDPATH**/ ?>