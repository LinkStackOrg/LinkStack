

<?php $__env->startSection('content'); ?>

<script src="<?php echo e(asset('resources/ckeditor/ckeditor.js')); ?>"></script>

<section class="shadow text-gray-400">
      <h2 class="mb-4 card-header"><i class="bi bi-person"> Edit Pages</i></h2>
      <div class="card-body p-0 p-md-3">
        
      <form action="<?php echo e(route('editSitePage')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="form-group col-lg-8">
            <h3>Terms</h3>
            <textarea class="form-control ckeditor" name="terms" rows="3"><?php echo e($page->terms); ?></textarea>
          </div><br>
          <div class="form-group col-lg-8">
            <h3>Privacy</h3>
            <textarea class="form-control ckeditor" name="privacy" rows="3"><?php echo e($page->privacy); ?></textarea>
          </div><br>
          <div class="form-group col-lg-8">
            <h3>Contact</h3>
            <textarea class="form-control ckeditor" name="contact" rows="3"><?php echo e($page->contact); ?></textarea>
          </div><br>
        <div class="form-group col-lg-8">
          <h3 for="exampleFormControlSelect1">Allow registration</h3>
          <select class="form-control" name="register">
		  <?php if($page->register == 'true'): ?>
            <option>true</option>
            <option>false</option>
		  <?php else: ?>
            <option>false</option>
            <option>true</option>
		  <?php endif; ?>
          </select>
        </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <button type="submit" class="mt-3 ml-3 btn btn-info">Submit</button>
        </form>

          </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/panel/pages.blade.php ENDPATH**/ ?>