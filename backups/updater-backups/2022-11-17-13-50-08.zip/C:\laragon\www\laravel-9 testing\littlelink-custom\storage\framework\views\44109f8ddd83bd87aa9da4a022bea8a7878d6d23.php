<title>Backup</title>


<?php $__env->startPush('updater-body'); ?>
<div class="container">


<?php if($_SERVER['QUERY_STRING'] === ''): ?>
<?php //landing page ?>
        
        <div class="logo-container fadein">
           <img class="logo-img" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="Logo">
           <div class="logo-centered">l</div>
        </div>
        <h1>Backup</h1>
        <h4 class="">You can back up your entire instance:</h4>
        <h5 class="">The backup system won't save more than two backups at a time.</h5>
        <br><div class="row">
        &ensp;<a class="btn" href="<?php echo e(url()->current()); ?>/?backup"><button><i class="fa-solid fa-floppy-disk"></i> Backup Instance</button></a>&ensp;
        &ensp;<a class="btn" href="<?php echo e(route('showBackups')); ?>"><button><i class="fa-solid fa-box-archive"></i> All Backups</button></a>&ensp;
        </div>
        <?php endif; ?>


<?php if($_SERVER['QUERY_STRING'] === 'backup'): ?>
<?php //creating backup... ?>
<?php $__env->startPush('updater-head'); ?>
<meta http-equiv="refresh" content="2; URL=<?php echo e(url()->current()); ?>/?backups" />
<?php $__env->stopPush(); ?>
        <div class="logo-container fadein">
           <img class="logo-img loading" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="Logo">
           <div class="logo-centered">l</div>
        </div>
        <h1 class="loadingtxt">Creating backup</h1>
<?php endif; ?>

<?php if($_SERVER['QUERY_STRING'] === 'backups'): ?>
<?php Artisan::call('backup:clean');
Artisan::call('backup:run', ['--only-files' => true]);
$tst = base_path('backups/');
file_put_contents($tst.'CANUPDATE', '');
$URL = Route::current()->getName();   
header("Location: ".$URL."?success");
exit(); ?>
<?php endif; ?>

<?php if($_SERVER['QUERY_STRING'] === 'success'): ?>
      <?php //after successfully updating ?>
        
        <div class="logo-container fadein">
           <img class="logo-img" src="<?php echo e(asset('littlelink/images/just-gear.svg')); ?>" alt="Logo">
           <div class="logo-centered">l</div>
        </div>
        <h1>Success!</h1>
        <h4 class="">The backup was successful, you can now return to the Admin Panel or see all your backups.</h4>
        <br><div class="row">
        &ensp;<a class="btn" href="<?php echo e(route('studioIndex')); ?>"><button><i class="fa-solid fa-house-laptop btn"></i> Admin Panel</button></a>&ensp;
        &ensp;<a class="btn" href="<?php echo e(route('showBackups')); ?>"><button><i class="fa-solid fa-box-archive"></i> All Backups</button></a>&ensp;
        </div>
<?php endif; ?>

</div>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.updater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/backup.blade.php ENDPATH**/ ?>