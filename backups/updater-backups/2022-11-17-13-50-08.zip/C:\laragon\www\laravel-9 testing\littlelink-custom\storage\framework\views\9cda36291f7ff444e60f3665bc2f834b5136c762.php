<?php if(env('CUSTOM_META_TAGS') == 'true' and config('advanced-config.lang') != ''): ?>
<html lang="<?php echo e(config('advanced-config.lang')); ?>">
<?php else: ?>
<html lang="en">
<?php endif; ?>



<?php if(env('FORCE_HTTPS') == 'true'): ?>
<?php
if (! isset($_SERVER['HTTPS']) or $_SERVER['HTTPS'] == 'off' ) {
    $redirect_url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("Location: $redirect_url");
    exit();
}
?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/layouts/lang.blade.php ENDPATH**/ ?>