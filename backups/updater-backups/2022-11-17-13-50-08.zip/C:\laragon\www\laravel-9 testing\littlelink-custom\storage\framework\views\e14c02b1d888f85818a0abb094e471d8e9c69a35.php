<div class="modal" tabindex="-1" role="dialog" id="<?php echo e($getModalIdString()); ?>">


    <div class="modal-dialog modal-dialog-scrollable" role="document">

        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo e($slot); ?>


            </div>
            <div class="modal-footer">
             <?php echo e($buttons); ?>


                
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/components/modal.blade.php ENDPATH**/ ?>