          <p>Allows editing the frontend of your site. Amongst other things, this file allows customization of:<br> 
Home Page, links, titles, Google Analytics and meta tags.</p>
        <form action="<?php echo e(route('editAC')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Advanced Configuration file.</label>
            <textarea style="width:100%;display:none;" class="form-control" name="AdvancedConfig" rows="280"><?php echo e(file_get_contents('config/advanced-config.php')); ?></textarea>
            <div id="editor" style="width:100%; height:<?php echo count(file('config/advanced-config.php')) * 24 + 15;?>px;" class="form-control" name="AdvancedConfig" rows="280"><?php echo e(file_get_contents('config/advanced-config.php')); ?></div>
          </div>
          <button type="submit" class="mt-3 ml-3 btn btn-info">Save</button>
          <a class="mt-3 ml-3 btn btn-primary confirmation" href="<?php echo e(url('/panel/advanced-config?restore-defaults')); ?>">Restore defaults</a>
          <script type="text/javascript">
              var elems = document.getElementsByClassName('confirmation');
              var confirmIt = function (e) {
                  if (!confirm('Are you sure?')) e.preventDefault();
              };
              for (var i = 0, l = elems.length; i < l; i++) {
                  elems[i].addEventListener('click', confirmIt, false);
              }
          </script>
        </form>


<script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.1/ace.js" type="text/javascript" charset="utf-8"></script>
<script>
var editor = ace.edit("editor");
editor.setTheme("ace/theme/xcode");
editor.getSession().setMode("ace/mode/javascript");
</script>
<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/components/config/advanced-config.blade.php ENDPATH**/ ?>