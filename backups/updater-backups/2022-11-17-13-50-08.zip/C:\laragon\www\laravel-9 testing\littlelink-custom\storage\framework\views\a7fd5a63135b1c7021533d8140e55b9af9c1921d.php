


<?php $__env->startSection('content'); ?>
<?php if($greeting == ''): ?>
<h3 class="mb-3"> 👋 Hi, stranger</h2>
    <h5>You do not have a Page URL set, yet you can change that on the <a href="<?php echo e(url('/studio/page')); ?>">Page section</a></h5>
    <?php else: ?>
    <h3 class="mb-3"> 👋 Hi, <?= $greeting ?></h2>
        <?php endif; ?>
        <p>
            Welcome to <?php echo e(config('app.name')); ?>!
        </p>


        <!-- Section: Design Block -->
        <section class="mb-3 text-gray-800 text-center shadow p-4 w-full">
            <div class='font-weight-bold text-left'>Visitor analytics:</div>
            <div class="d-flex flex-wrap justify-content-around">

                <div class="p-2">
                    <h3 class="text-primary"><strong><?php echo e($pageStats['visitors']['day']); ?></strong></h3>
                    <span class="text-muted">Today</span>

                </div>

                <div class="p-2">
                    <h3 class="text-primary"><strong><?php echo e($pageStats['visitors']['week']); ?></strong></h3>
                    <span class="text-muted">Week</span>


                </div>

                <div class="p-2">
                    <h3 class="text-primary"><strong><?php echo e($pageStats['visitors']['month']); ?></strong></h3>
                    <span class="text-muted">Month</span>


                </div>
                <div class="p-2">
                    <h3 class="text-primary"><strong><?php echo e($pageStats['visitors']['year']); ?></strong></h3>
                    <span class="text-muted">Year</span>


                </div>
                <div class="p-2">
                    <h3 class="text-primary"><strong><?php echo e($pageStats['visitors']['all']); ?></strong></h3>
                    <span class="text-muted">All Time</span>


                </div>

            </div>
        </section>



        <section class="mb-3 text-center shadow p-4 w-full">
            <div class=" d-flex">

                <div class='p-2 h6'><i class="bi bi-link"></i> Total Links: <span class='text-primary'><?php echo e($links); ?> </span></div>

                <div class='p-2 h6'><i class="bi bi-eye"></i> Link Clicks: <span class='text-primary'><?php echo e($clicks); ?></span></div>
            </div>
            <div class='text-center w-100'>
                <a href="<?php echo e(url('/studio/links')); ?>">View/Edit Links</a>

            </div>
            <div class='w-100 text-left'>
                <h6><i class="bi bi-sort-up"></i> Top Links:</h6>

                                <?php $i = 0; ?>


                <?php $__currentLoopData = $toplinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $linkName = str_replace('default ','',$link->name) ?>
                <?php  $i++; ?>
                <ol class='list-group list-group-flush bg-transparent'>

                <?php if($link->name !== "phone" && $link->name !== 'heading'): ?>
                <li class="list-group-item bg-transparent">
                  <?php echo e($i); ?>.)  <?php echo e($link->title); ?> -- <span class='text-primary' title='Click Count'><?php echo e($link->click_number); ?>  </span> <br />


                    <a href="<?php echo e($link->link); ?>" class='small ml-3' title='<?php echo e($link->link); ?>' target="_blank"><?php echo e($link->link); ?></a></li>

                <?php endif; ?>
                </ol>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/studio/index.blade.php ENDPATH**/ ?>