<section class="shadow text-gray-400">
<h2 class="mb-4 card-header"><i class="bi bi-pencil-square"> .ENV</i></h2>
<div class="card-body p-0 p-md-3">


        <form action="<?php echo e(route('editENV')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Strings with a # in front of them are comments and wont affect anything.</label>
            <textarea style="width:100%!important;display:none;" class="form-control" name="altConfig" rows="<?php echo e(count(file('.env'))); ?>"><?php echo e(file_get_contents('.env')); ?></textarea>
            <div id="editor2" style="width:100%; height:<?php echo count(file('.env')) * 24 + 50;?>px;" class="form-control" name="altConfig" rows="280"><?php echo e(file_get_contents('.env')); ?></div>
          </div>
          <button type="submit" class="mt-3 ml-3 btn btn-info">Save</button>
        </form>

<script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.1/ace.js" type="text/javascript" charset="utf-8"></script>
<script>
var editor = ace.edit("editor2");
editor.setTheme("ace/theme/xcode");
editor.getSession().setMode("ace/mode/ruby");
</script>
<script>
editor.getSession().on('change', function(e) {
$('textarea[name=altConfig]').val(editor.getSession().getValue());
});
</script>


</div>
</section>

<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/components/config/alternative-config.blade.php ENDPATH**/ ?>