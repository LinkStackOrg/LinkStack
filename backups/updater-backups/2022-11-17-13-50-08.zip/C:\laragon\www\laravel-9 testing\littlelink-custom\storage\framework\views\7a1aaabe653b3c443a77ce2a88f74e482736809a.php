

<?php $__env->startSection('content'); ?>

<section class=' shadow text-gray-400'>

    <h3 class="card-header"><i class="bi bi-journal-plus"> <?php if($LinkID !== 0): ?> Edit <?php else: ?> Add <?php endif; ?> Page Item</i></h3>

    <div class='card-body'>
        <form action="<?php echo e(route('addLink')); ?>" method="post">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>
            <input type='hidden' name='linkid' value="<?php echo e($LinkID); ?>" />

            <div class="form-group col-lg-8 flex justify-around">
                <label class='font-weight-bold'>Blocks: </label>
                <div class="btn-group shadow m-2">
                    <button type="button" id='btnLinkType' class="border-0 p-1" title='Click to change link blocks' data-toggle="modal" data-target="#SelectLinkType"><?php echo e($title); ?></button>



                    <button type="button" class="dropdown-toggle border-0 border-left-1 px-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu">
                        <?php $__currentLoopData = $LinkTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a data-typeid='<?php echo e($lt['id']); ?>' data-typename='<?php echo e($lt['title']); ?>' class="dropdown-item doSelectLinkType" href="#">
                            <i class="<?php echo e($lt['icon']); ?>"></i> <?php echo e($lt['title']); ?>

                        </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                    <input type='hidden' name='linktype_id' value='<?php echo e($linkTypeID); ?>'>

                </div>
            </div>

            


            <div id='link_params' class='col-lg-8'></div>


            <div class="row">
                <a class="btn btn-secondary mt-3 ml-3 btn" href="<?php echo e(url()->previous()); ?>">Cancel</a>
                <button type="submit" class="mt-3 ml-3 btn btn-primary">Save</button>
            </div>


        </form>
    </div>
</section>
<br><br>




<!-- Modal -->
<style>.modal-title{color:#000!important;}</style>
<?php if (isset($component)) { $__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modal::class, ['title' => 'Select Block','id' => 'SelectLinkType']); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="d-flex flex-row  flex-wrap p-3">

        <?php $__currentLoopData = $LinkTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#" data-typeid='<?php echo e($lt['id']); ?>' data-typename='<?php echo e($lt['title']); ?>'' class="hvr-grow m-2 w-100 d-block doSelectLinkType">


            <div class="card w-100">
                <div class="row no-gutters">
                    <div class="col-auto bg-light justify-content-center p-3">
                        <i class="card-img h1 text-primary <?php echo e($lt['icon']); ?> d-block"></i>
                    </div>
                    <div class="col">
                        <div class="card-body">
                            <h5 style="color:#000!important;" class="card-title mb-0"><?php echo e($lt['title']); ?></h5>
                            <p class="card-text text-muted"><?php echo e($lt['description']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

     <?php $__env->slot('buttons', null, []); ?> 
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c)): ?>
<?php $component = $__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c; ?>
<?php unset($__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush("sidebar-scripts"); ?>
<script>
$(function() {
    LoadLinkTypeParams($("input[name='linktype_id']").val() , $("input[name=linkid]").val());

    $('.doSelectLinkType').on('click', function() {
        $("input[name='linktype_id']").val($(this).data('typeid'));
        $("#btnLinkType").html($(this).data('typename'));

        LoadLinkTypeParams($(this).data('typeid'), $("input[name=linkid]").val());

        $('#SelectLinkType').modal('hide');
    });


    function LoadLinkTypeParams($TypeId, $LinkId) {
        var baseURL = <?php echo "\"" . url('') . "\""; ?>;
        $("#link_params").html(' <img width="70px" src="' + baseURL + '/img/loading.gif" />').load(baseURL + `/studio/linkparamform_part/${$TypeId}/${$LinkId}`);

    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/studio/edit-link.blade.php ENDPATH**/ ?>