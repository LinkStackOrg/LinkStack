<?php if(file_exists(base_path("/littlelink/images/avatar.png" ))): ?>
    <img class="mb-5" src="<?php echo e(asset('/littlelink/images/avatar.png')); ?>" srcset="<?php echo e(asset('/littlelink/images/avatar@2x.png 2x')); ?>" style="width: 150px;">
<?php else: ?>
    <img class="mb-5" src="<?php echo e(asset('/littlelink/images/avatar@2x.png')); ?>">
<?php endif; ?>
<?php /**PATH C:\laragon\www\laravel-9 testing\littlelink-custom\resources\views/components/application-logo.blade.php ENDPATH**/ ?>